let express = require("express");
let app     = express();
const port = process.env.PORT || 3000;

const server = app.listen(port);
console.log(`Running at Port ${port}`);
server.timeout = 1000 * 60 * 2; // 2 minutes


/*
Aufgabe 1
a) Erstellen Sie ein Array mit 10 Einträgen von aktuellen Musikbands, der von diesem
Server aufgerufen werden kann.
b) Die URL muss http://localhost:3000/musicbands lauten
c) Aus der List von 1a soll per Zufall eine Musikband zurückgegeben werden (HTTP Response)
d) Fügen Sie die korrekten Headers ein, damit CORS Requests beantworten werden.
 */


app.use(function (req, res, next) {
    //Lösung 1d
    res.header('Access-Control-Allow-Origin', 'http://localhost:63342');
    res.header('Content-Type', 'application/json');
    next();
});


//Lösung 1a
const musicbandsPuzzleList = ["Rihanna", "Beyonce", "Jay-z", "Chris Brown",
    "Stormzy", "Koffee", "Billie Eilish", "Ed Sheeran",
    "Post Malone", "A$AP Rocky "];




//Lösung 1b/c
    app.get('/musicbands', (req, res) => {
        const random = Math.floor(Math.random() * musicbandsPuzzleList.length);
        res.send(JSON.stringify({puzzle: musicbandsPuzzleList[random]}));
    });

