## README
Befolgen Sie die Anleitung auf ict.bzzlab.ch gemäss Ihrem Jahrgang.
